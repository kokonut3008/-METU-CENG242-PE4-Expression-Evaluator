#include <iostream>
#include "expr.h"
#include "nullary.h"
#include "unary.h"
#include "binary.h"
#include "type.h"
#include "core.h"

int main() {
    sym::Var x = "x";
    sym::Expr op = (exp(x) * x) + (-x * exp(x));

   std::cout << "expression: " << op << std::endl;
   std::cout << "differention: " << *op.diff(x) << std::endl;
}
