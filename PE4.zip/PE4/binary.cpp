#include "binary.h"
#include "nullary.h"
#include <math.h>

namespace sym 
{
	bool AddOp::is_add() const {
	    return true;
	}

	__expr_t* AddOp::eval(const var_map_t& vars) const {
	    const Const* left = dynamic_cast<const Const*>(lhs_->eval(vars));
	    const Const* right = dynamic_cast<const Const*>(rhs_->eval(vars));
	    if(left){
    	    if(left->get_value() == 0){
    	        delete left;
    	        delete right;
    	        return rhs_->eval(vars);
    	    }
	    }
	    if(right){   
    	    if(right->get_value() == 0){
    	        delete left;
    	        delete right;
    	        return lhs_->eval(vars);
    	    }   
	    }
	    if(left && right){
	        double val1, val2;
	        val1 = left->get_value();
	        val2 = right->get_value();
	        delete left;
	        delete right;
	        return new Const (val1 + val2);
	    }
	    else{
	        delete left;
	        delete right;
            return new AddOp(lhs_->eval(vars), rhs_->eval(vars));
	    }
	}

	__expr_t* AddOp::diff(const std::string& v) const {
	    const Const* left = dynamic_cast<const Const*>(lhs_->diff(v));
	    const Const* right = dynamic_cast<const Const*>(rhs_->diff(v));
	    if(left && right){
	        double val1 = left->get_value();
	        double val2 = right->get_value();
	        delete left; delete right;
	        return new Const(val1 + val2);
	    }
	    if(left){
    	    if(left->get_value() == 0){
    	        delete left;
    	        delete right;
    	        return rhs_->diff(v);
    	    }
	    }
	    if(right){
            if(right->get_value() == 0){
                delete left;
    	        delete right;
    	        return lhs_->diff(v);
            }
	    }
        delete left;
	    delete right;
	    return new AddOp(lhs_->diff(v), rhs_->diff(v));
	}

	std::ostream& AddOp::operator<< (std::ostream &out) const {
	    const Const* newConst = dynamic_cast<const Const*>(lhs_);
	    const Var* newVar = dynamic_cast<const Var*>(lhs_);
        if (!newConst && !newVar) {
            out << "(";
        }
        out << *lhs_;
        if (!newConst && !newVar) {
            out << ")";
        }
        
        out << " + ";
        
        const Const* newConst1 = dynamic_cast<const Const*>(rhs_);
        const Var* newVar1 = dynamic_cast<const Var*>(rhs_);
        
        if (!newConst1 && !newVar1) {
            out << "(";
        }
        out << *rhs_;
        if (!newConst1 && !newVar1) {
            out << ")";
        }

        return out;
	    
	}

	bool AddOp::operator==(const __expr_t& other_) const {
	    const AddOp *newAdd = dynamic_cast<const AddOp*>(&other_);
	    if(newAdd){
	        bool flag1 = lhs_ == newAdd->lhs_ && rhs_ == newAdd->rhs_;
	        bool flag2 = lhs_ == newAdd->rhs_ && rhs_ == newAdd->lhs_;
	        delete newAdd;
	        return flag1 || flag2; 
	    }
	    return false;
	}
}

namespace sym 
{
	bool MulOp::is_mul() const {
	    return true;
	}

	__expr_t* MulOp::eval(const var_map_t& vars) const {
	    const Const* left = dynamic_cast<const Const*>(lhs_->eval(vars));
	    const Const* right = dynamic_cast<const Const*>(rhs_->eval(vars));
        if(left){    
            if(left->get_value() == 0){
        	    delete left;
        	    delete right;
        	    return new Const(0.0);
            }
        }
        if(right){
    	    if(right->get_value() == 0 ){
        	    delete left;
        	    delete right;
        	    return new Const(0.0);
        	}
        }
        if(left){
            if(left->get_value() == 1){
    	        delete left;
    	        delete right;
    	        return rhs_->eval(vars);
    	        
    	    }
        }
        if(right){
    	    if(right->get_value() == 1){
    	        delete left;
    	        delete right;
    	        return lhs_->eval(vars);
    	    }
        }
	    if(left && right){
	        double val1, val2;
	        val1 = left->get_value();
	        val2 = right->get_value();
	        delete left;
	        delete right;
	        return new Const (val1 * val2);
	    }
	    else{
	        delete left;
	        delete right;
            return new MulOp(lhs_->eval(), rhs_->eval());
	    }
	    
	}

	__expr_t* MulOp::diff(const std::string& v) const {
	        return  AddOp(MulOp(lhs_->diff(v), rhs_).eval(), MulOp(lhs_, rhs_->diff(v)).eval()).eval();
	}

	std::ostream& MulOp::operator<< (std::ostream &out) const {
	    const Const* newConst = dynamic_cast<const Const*>(lhs_);
	    const Var* newVar = dynamic_cast<const Var*>(lhs_);
        if (!newConst && !newVar) {
            out << "(";
        }
        out << *lhs_;
        if (!newConst && !newVar) {
            out << ")";
        }
        
        out << " * ";
        
        const Const* newConst1 = dynamic_cast<const Const*>(rhs_);
        const Var* newVar1 = dynamic_cast<const Var*>(rhs_);
        
        if (!newConst1 && !newVar1) {
            out << "(";
        }
        out << *rhs_;
        if (!newConst1 && !newVar1) {
            out << ")";
        }
        
        return out;
	    
	}

	bool MulOp::operator==(const __expr_t& other_) const {
	    const MulOp *newAdd = dynamic_cast<const MulOp*>(&other_);
	    if(newAdd){
	        bool flag1 = lhs_ == newAdd->lhs_ && rhs_ == newAdd->rhs_;
	        bool flag2 = lhs_ == newAdd->rhs_ && rhs_ == newAdd->lhs_;
	        delete newAdd;
	        return flag1 || flag2; 
	    }
	    return false;
	    
	}
}
