#include "core.h"


namespace sym {
	bool __expr_t::is_unary() const { }
	bool __expr_t::is_binary() const { }
	bool __expr_t::is_nullary() const { }
}
