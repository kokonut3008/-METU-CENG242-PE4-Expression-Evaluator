#include "nullary.h"
#include "unary.h"
#include "binary.h"

namespace sym {
	__expr_t& operator-(const __expr_t &op) {
	    NegOp* negOp= new NegOp(op.eval());
	    return *negOp;
	}
	__expr_t& exp(const __expr_t &op) { 
	    ExpOp* expOp= new ExpOp(op.eval());
	    return *expOp;
	}

	__expr_t& operator+(const __expr_t &lhs, const __expr_t &rhs) {
	    AddOp* addOp= new AddOp(lhs.eval(), rhs.eval());
	    return *addOp;
	}
	
	__expr_t& operator+(double lhs, const __expr_t &rhs) {
	    
	    Const* newConst= new Const(lhs);
	    AddOp* addOp= new AddOp(newConst, rhs.eval());
	    return *addOp;
	    
	}
	__expr_t& operator+(const __expr_t &lhs, double rhs) { 
	    Const* newConst = new Const(rhs);
	    AddOp* addOp = new AddOp(lhs.eval(), newConst);
	    return *addOp;
	}

	__expr_t& operator*(const __expr_t &lhs, const __expr_t &rhs) {
	    MulOp* mulOp= new MulOp(lhs.eval(), rhs.eval());
	    return *mulOp;
	}
	__expr_t& operator*(double lhs, const __expr_t &rhs) {
	    Const* newConst = new Const(lhs);
	    MulOp* mulOp = new MulOp(newConst, rhs.eval());
	    return *mulOp;}
	__expr_t& operator*(const __expr_t &lhs, double rhs) {
	    Const* newConst = new Const(rhs);
	    MulOp* mulOp = new MulOp(lhs.eval(), newConst);
	    return *mulOp;
}
}
