#include "nullary.h"
#include "unary.h"
#include "binary.h"

#include <math.h>

namespace sym 
{
	bool NegOp::is_neg() const {
        return true;
	}

    __expr_t* NegOp::eval(const var_map_t& vars) const {
	    const Const* opEval = dynamic_cast<const Const*>(operand->eval(vars));
        if (opEval) {
            double value = opEval->get_value();
            delete opEval;
            return new Const(-value);
        } else {
            return new NegOp(operand->eval(vars));
        }
}

	__expr_t* NegOp::diff(const std::string& v) const {
        return new NegOp(operand->diff(v));
	}

	std::ostream& NegOp::operator<< (std::ostream &out) const {
        out << "-";
        const Const* newConst = dynamic_cast<const Const*>(operand);
        const Var* newVar = dynamic_cast<const Var*>(operand);
        if (!newConst && !newVar) {
            out << "(";
        }
        out << *operand;
        if (!newConst && !newVar) {
            out << ")";
        }

        return out;
}

	bool NegOp::operator==(const __expr_t& other_) const {
	    const NegOp* newNeg = dynamic_cast<const NegOp*>(&other_);
	    if(newNeg){
	        bool flag = operand == newNeg->operand;
	        delete newNeg;
	        return flag;
	    }
	    else{
	        return false;
	    }
	}
}

namespace sym 
{
	bool ExpOp::is_exp() const {
	    return true;
	}

	__expr_t* ExpOp::eval(const var_map_t& vars) const {
	    const Const* opEval = dynamic_cast<const Const*>(operand->eval(vars)); 
	    if (opEval) {
            double value = expf(opEval->get_value());
            delete opEval;
            return new Const(value);
        } else {
            delete opEval;
            return new ExpOp(operand->eval(vars));
        }
	    
	}

	__expr_t* ExpOp::diff(const std::string& v) const {
	    const Const* newConst = dynamic_cast<const Const*>(operand);
	    const Const* constDiff = dynamic_cast<const Const*>(operand->diff(v));
	    if(newConst){
	        delete constDiff;
	        return new Const(0.0);
	    }
	        
        else if (constDiff && constDiff->get_value() == 1){
	        delete constDiff;
            return new ExpOp(operand);
        }
        else{
	        delete constDiff;
            return new MulOp (operand->diff(v), this);
        }    
	}

	std::ostream& ExpOp::operator<< (std::ostream &out) const {
	    out << "e^";
        const Const* newConst = dynamic_cast<const Const*>(operand);
        const Var* newVar = dynamic_cast<const Var*>(operand);
        if (!newConst && !newVar) {
            out << "(";
        }
        out << *operand;
        if (!newConst && !newVar) {
            out << ")";
        }

        return out;
	    
	}

	bool ExpOp::operator==(const __expr_t& other_) const {
	    const ExpOp* newExp = dynamic_cast<const ExpOp*>(&other_);
	    if(newExp){
	        auto newOper = newExp->operand;
	        delete newExp;
	        return operand == newOper;
	    }
	        
	    else{
	        return false;
	    }
	    
	}
}
